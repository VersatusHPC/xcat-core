package xCAT::DHCP::Backend::Kea;

use strict;
use warnings;

use JSON;
use File::Basename;
use File::Path qw/make_path/;
use Math::BigInt;
use Text::ParseWords qw/shellwords/;
use xCAT::CommandUtils;
use xCAT::DHCP::Range;
use xCAT::NetworkUtils;

my @KEA_ACCOUNT_CANDIDATES = ( 'kea', '_kea' );

sub new {
    my ( $class, %args ) = @_;
    return bless \%args, $class;
}

sub name {
    return 'kea';
}

# The backend auto-selection preferred, and undef when it did not fall back. #7710
sub fallback_from {
    my $self = shift;
    return ref($self) ? $self->{selection}{fallback_from} : undef;
}

sub implemented {
    return 1;
}

sub dhcp4_config_file {
    my ($self) = @_;
    return $self->{dhcp4_config_file} || '/etc/kea/kea-dhcp4.conf';
}

sub dhcp6_config_file {
    my ($self) = @_;
    return $self->{dhcp6_config_file} || '/etc/kea/kea-dhcp6.conf';
}

sub ctrl_agent_config_file {
    my ($self) = @_;
    return $self->{ctrl_agent_config_file} || '/etc/kea/kea-ctrl-agent.conf';
}

sub ddns_config_file {
    my ($self) = @_;
    return $self->{ddns_config_file} || '/etc/kea/kea-dhcp-ddns.conf';
}

sub control_socket_path {
    my ( $self, $socket_name ) = @_;

    return $self->_kea_socket_dir() . "/$socket_name";
}

sub service_account {
    foreach my $user (@KEA_ACCOUNT_CANDIDATES) {
        my @entry = getpwnam($user);
        return {
            name => $entry[0],
            uid  => $entry[2],
            gid  => $entry[3],
        } if @entry;
    }

    return;
}

sub render_dhcp4_config {
    my ( $self, $intent ) = @_;

    $intent ||= {};

    my %dhcp4 = (
        'interfaces-config' => {
            interfaces => $intent->{interfaces} || [],
        },
        'lease-database' => _first_defined( $intent->{'lease-database'}, $intent->{lease_database} ) || {
            type => 'memfile',
            name => '/var/lib/kea/kea-leases4.csv',
        },
        'valid-lifetime'           => _integer( _first_defined( $intent->{'valid-lifetime'}, $intent->{valid_lifetime}, 43200 ) ),
        'reservations-in-subnet'   => _json_bool( _first_defined( $intent->{'reservations-in-subnet'},   $intent->{reservations_in_subnet},   1 ) ),
        'reservations-out-of-pool' => _json_bool( _first_defined( $intent->{'reservations-out-of-pool'}, $intent->{reservations_out_of_pool}, 1 ) ),
        'match-client-id'          => _json_bool( _first_defined( $intent->{'match-client-id'},          $intent->{match_client_id},          0 ) ),
        # ISC writes "authoritative;" into every subnet; Kea defaults to the
        # opposite, so a node that moved rack asks to keep an address from a
        # network it has left and is answered with nothing at all -- waiting out
        # a lease that will never be renewed instead of starting over.
        'authoritative'            => _json_bool( _first_defined( $intent->{authoritative},             1 ) ),
        subnet4                    => [ map { $self->_render_subnet4($_) } @{ _first_defined( $intent->{subnet4}, $intent->{subnets}, [] ) } ],
    );

    $dhcp4{'control-socket'}  = $intent->{'control-socket'}  if $intent->{'control-socket'};
    $dhcp4{'hooks-libraries'} = $intent->{'hooks-libraries'} if $intent->{'hooks-libraries'};
    $dhcp4{'option-def'} = $intent->{'option-def'} if $intent->{'option-def'};
    $dhcp4{'client-classes'} = [ map { $self->_render_client_class($_) } @{ $intent->{'client-classes'} } ] if $intent->{'client-classes'};
    $dhcp4{'option-data'} = _render_option_data( $intent->{'option-data'} )
      if $intent->{'option-data'};
    $dhcp4{'dhcp-ddns'}      = $intent->{'dhcp-ddns'}   if $intent->{'dhcp-ddns'};
    foreach my $field (qw/ddns-send-updates ddns-override-no-update ddns-override-client-update ddns-qualifying-suffix ddns-update-on-renew/) {
        $dhcp4{$field} = $intent->{$field} if exists $intent->{$field};
    }

    return JSON->new->canonical->pretty->encode( { Dhcp4 => \%dhcp4 } );
}

sub render_dhcp6_config {
    my ( $self, $intent ) = @_;

    $intent ||= {};

    my %dhcp6 = (
        'interfaces-config' => {
            interfaces => $intent->{interfaces} || [],
        },
        'lease-database' => _first_defined( $intent->{'lease-database'}, $intent->{lease_database} ) || {
            type => 'memfile',
            name => '/var/lib/kea/kea-leases6.csv',
        },
        'preferred-lifetime' => _integer( _first_defined( $intent->{'preferred-lifetime'}, $intent->{preferred_lifetime}, 43200 ) ),
        'valid-lifetime'     => _integer( _first_defined( $intent->{'valid-lifetime'},     $intent->{valid_lifetime},     43200 ) ),
        'host-reservation-identifiers' => _first_defined( $intent->{'host-reservation-identifiers'}, [ 'duid', 'hw-address' ] ),
        subnet6              => [ map { $self->_render_subnet6($_) } @{ _first_defined( $intent->{subnet6}, $intent->{subnets}, [] ) } ],
    );

    $dhcp6{'control-socket'}  = $intent->{'control-socket'}  if $intent->{'control-socket'};
    $dhcp6{'hooks-libraries'} = $intent->{'hooks-libraries'} if $intent->{'hooks-libraries'};
    $dhcp6{'option-data'} = _render_option_data( $intent->{'option-data'} )
      if $intent->{'option-data'};
    $dhcp6{'dhcp-ddns'}       = $intent->{'dhcp-ddns'}       if $intent->{'dhcp-ddns'};
    foreach my $field (qw/ddns-send-updates ddns-override-no-update ddns-override-client-update ddns-qualifying-suffix ddns-update-on-renew/) {
        $dhcp6{$field} = $intent->{$field} if exists $intent->{$field};
    }

    return JSON->new->canonical->pretty->encode( { Dhcp6 => \%dhcp6 } );
}

sub render_ddns_config {
    my ( $self, $intent ) = @_;

    $intent ||= {};
    my $forward_domains = $intent->{forward_domains};
    $forward_domains = $intent->{'forward-ddns'}{'ddns-domains'}
      if !defined($forward_domains) && ref( $intent->{'forward-ddns'} ) eq 'HASH';
    $forward_domains ||= [];
    my $reverse_domains = $intent->{reverse_domains};
    $reverse_domains = $intent->{'reverse-ddns'}{'ddns-domains'}
      if !defined($reverse_domains) && ref( $intent->{'reverse-ddns'} ) eq 'HASH';
    $reverse_domains ||= [];

    my %ddns = (
        'ip-address'         => $intent->{'ip-address'} || '127.0.0.1',
        port                 => _integer( $intent->{port} || 53001 ),
        'dns-server-timeout' => _integer( _first_defined( $intent->{'dns-server-timeout'}, 500 ) ),
        'ncr-protocol'       => $intent->{'ncr-protocol'} || 'UDP',
        'ncr-format'         => $intent->{'ncr-format'} || 'JSON',
        'tsig-keys'          => $intent->{'tsig-keys'} || [],
        'forward-ddns'       => {
            'ddns-domains' => $forward_domains,
        },
        'reverse-ddns' => {
            'ddns-domains' => $reverse_domains,
        },
    );

    $ddns{'control-sockets'} = $intent->{'control-sockets'} if $intent->{'control-sockets'};

    return JSON->new->canonical->pretty->encode( { DhcpDdns => \%ddns } );
}

sub render_ctrl_agent_config {
    my ( $self, $intent ) = @_;

    $intent ||= {};

    my %sockets = (
        dhcp4 => {
            'socket-type' => 'unix',
            'socket-name' => $intent->{'dhcp4-socket'} || $self->control_socket_path('kea4-ctrl-socket'),
        },
    );
    if ( $intent->{dhcp6} || $intent->{'dhcp6-socket'} ) {
        $sockets{dhcp6} = {
            'socket-type' => 'unix',
            'socket-name' => $intent->{'dhcp6-socket'} || $self->control_socket_path('kea6-ctrl-socket'),
        };
    }
    if ( $intent->{ddns} || $intent->{'ddns-socket'} ) {
        $sockets{d2} = {
            'socket-type' => 'unix',
            'socket-name' => $intent->{'ddns-socket'} || $self->control_socket_path('kea-ddns-ctrl-socket'),
        };
    }

    my $agent = {
        'http-host'       => $intent->{'http-host'} || '127.0.0.1',
        'http-port'       => _integer( $intent->{'http-port'} || 8000 ),
        'control-sockets' => \%sockets,
    };
    $agent->{authentication} = $intent->{authentication} if $intent->{authentication};

    my $config = {
        'Control-agent' => $agent,
    };

    return JSON->new->canonical->pretty->encode($config);
}

# Where a distribution puts a Kea hook library. The name of the hook is the
# only thing that varies, and where the packages put them does not.
sub hook_path {
    my ( $self, $hook, @extra_paths ) = @_;

    my $override = "${hook}_hook_paths";
    my @default_paths = exists $self->{$override}
      ? @{ $self->{$override} || [] }
      : (
        "/usr/lib64/kea/hooks/libdhcp_$hook.so",
        "/usr/lib/kea/hooks/libdhcp_$hook.so",
        "/usr/local/lib/kea/hooks/libdhcp_$hook.so",
        glob("/usr/lib/*/kea/hooks/libdhcp_$hook.so"),
      );

    foreach my $path (
        @extra_paths,
        @default_paths,
      )
    {
        return $path if defined($path) && -e $path;
    }

    return;
}

sub host_cmds_hook_path {
    my ( $self, @extra_paths ) = @_;
    return $self->hook_path( 'host_cmds', @extra_paths );
}

# BOOTP is a hook on Kea and a range keyword on ISC, but it is the same
# decision either way: a client that speaks BOOTP and not DHCP is answered.
sub bootp_hook_path {
    my ( $self, @extra_paths ) = @_;
    return $self->hook_path( 'bootp', @extra_paths );
}

sub load_dhcp4_config {
    my ( $self, $path ) = @_;

    $path ||= $self->dhcp4_config_file();
    return { Dhcp4 => { subnet4 => [] } } unless -e $path;

    open( my $fh, '<', $path ) or return { error => "Unable to read $path: $!" };
    local $/;
    my $content = <$fh>;
    close($fh);

    my $json = eval { _decode_kea_json($content) };
    return { error => "Unable to parse $path as JSON: $@" } if $@;

    $json->{Dhcp4}{subnet4} ||= [];
    return $json;
}

sub load_dhcp6_config {
    my ( $self, $path ) = @_;

    $path ||= $self->dhcp6_config_file();
    return { Dhcp6 => { subnet6 => [] } } unless -e $path;

    open( my $fh, '<', $path ) or return { error => "Unable to read $path: $!" };
    local $/;
    my $content = <$fh>;
    close($fh);

    my $json = eval { _decode_kea_json($content) };
    return { error => "Unable to parse $path as JSON: $@" } if $@;

    $json->{Dhcp6}{subnet6} ||= [];
    return $json;
}

sub write_dhcp4_config {
    my ( $self, $intent, %opts ) = @_;

    return $self->write_dhcp4_json( $self->render_dhcp4_config($intent), %opts );
}

sub write_dhcp6_config {
    my ( $self, $intent, %opts ) = @_;

    return $self->write_dhcp6_json( $self->render_dhcp6_config($intent), %opts );
}

sub write_ddns_config {
    my ( $self, $intent, %opts ) = @_;

    return $self->write_ddns_json( $self->render_ddns_config($intent), %opts );
}

sub write_dhcp4_json {
    my ( $self, $json, %opts ) = @_;

    $opts{path} ||= $self->dhcp4_config_file();
    $opts{validator} ||= sub { $self->validate_dhcp4_config(@_) };
    return $self->_write_json_file( $json, %opts );
}

sub write_dhcp6_json {
    my ( $self, $json, %opts ) = @_;

    $opts{path} ||= $self->dhcp6_config_file();
    $opts{validator} ||= sub { $self->validate_dhcp6_config(@_) };
    return $self->_write_json_file( $json, %opts );
}

sub write_ddns_json {
    my ( $self, $json, %opts ) = @_;

    $opts{path} ||= $self->ddns_config_file();
    $opts{validator} ||= sub { $self->validate_ddns_config(@_) };
    return $self->_write_json_file( $json, %opts );
}

sub _write_json_file {
    my ( $self, $json, %opts ) = @_;

    my $path = $opts{path};
    my $dir  = dirname($path);
    make_path($dir) unless -d $dir;

    my $tmp = "$path.xcat.$$";
    open( my $fh, '>', $tmp ) or return { error => "Unable to write $tmp: $!" };
    print $fh $json;
    close($fh) or return { error => "Unable to close $tmp: $!" };
    my $permissions = _set_config_permissions($tmp);
    if ( $permissions->{error} ) {
        unlink $tmp;
        return $permissions;
    }

    if ( !$opts{skip_validate} ) {
        my $validation = $opts{validator}->($tmp);
        if ( $validation->{error} ) {
            unlink $tmp;
            return $validation;
        }
    }

    my $backup;
    if ( $opts{backup_existing} && -e $path ) {
        $backup = "$path.xcatbak";
        rename( $path, $backup ) or do {
            unlink $tmp;
            return { error => "Unable to back up $path to $backup: $!" };
        };
    }

    unless ( rename( $tmp, $path ) ) {
        my $rename_error = $!;
        rename( $backup, $path ) if $backup && -e $backup;
        unlink $tmp;
        return { error => "Unable to replace $path: $rename_error" };
    }

    return { path => $path, backup => $backup };
}

sub encode_config {
    my ( $self, $config ) = @_;

    # makedhcp <node> adds classes to a loaded config without the renderer.
    foreach my $family (qw/Dhcp4 Dhcp6/) {
        my $scope = ref($config) eq 'HASH' ? $config->{$family} : undef;
        next unless ref($scope) eq 'HASH' and $scope->{'client-classes'};
        $scope->{'client-classes'} = _render_entry_option_data( $scope->{'client-classes'} );
    }

    return JSON->new->canonical->pretty->encode($config);
}

sub _decode_kea_json {
    my ($content) = @_;

    # Kea accepts JSON with C/C++ comments and trailing commas. JSON->relaxed
    # is backend-dependent, so normalize these Kea extensions explicitly before
    # handing the content to the strict decoder.
    return decode_json( _strip_json_trailing_commas( _strip_json_comments($content) ) );
}

sub _strip_json_comments {
    my ($content) = @_;

    my $out = '';
    my $in_string = 0;
    my $escaped = 0;
    my $length = length($content);

    for ( my $idx = 0; $idx < $length; $idx++ ) {
        my $char = substr( $content, $idx, 1 );
        my $next = $idx + 1 < $length ? substr( $content, $idx + 1, 1 ) : '';

        if ($in_string) {
            $out .= $char;
            if ($escaped) {
                $escaped = 0;
            } elsif ($char eq '\\') {
                $escaped = 1;
            } elsif ($char eq '"') {
                $in_string = 0;
            }
            next;
        }

        if ($char eq '"') {
            $in_string = 1;
            $out .= $char;
            next;
        }

        if ($char eq '/' && $next eq '/') {
            $idx += 2;
            $idx++ while $idx < $length && substr( $content, $idx, 1 ) !~ /\n/;
            $out .= "\n" if $idx < $length;
            next;
        }

        if ($char eq '/' && $next eq '*') {
            $idx += 2;
            while ( $idx < $length - 1 && substr( $content, $idx, 2 ) ne '*/' ) {
                $out .= "\n" if substr( $content, $idx, 1 ) eq "\n";
                $idx++;
            }
            $idx++ if $idx < $length;
            next;
        }

        $out .= $char;
    }

    return $out;
}

sub _strip_json_trailing_commas {
    my ($content) = @_;

    my $out = '';
    my $in_string = 0;
    my $escaped = 0;
    my $length = length($content);

    for ( my $idx = 0; $idx < $length; $idx++ ) {
        my $char = substr( $content, $idx, 1 );

        if ($in_string) {
            $out .= $char;
            if ($escaped) {
                $escaped = 0;
            } elsif ($char eq '\\') {
                $escaped = 1;
            } elsif ($char eq '"') {
                $in_string = 0;
            }
            next;
        }

        if ($char eq '"') {
            $in_string = 1;
            $out .= $char;
            next;
        }

        if ($char eq ',') {
            my $lookahead = $idx + 1;
            $lookahead++ while $lookahead < $length && substr( $content, $lookahead, 1 ) =~ /\s/;
            my $next = $lookahead < $length ? substr( $content, $lookahead, 1 ) : '';
            next if $next eq '}' || $next eq ']';
        }

        $out .= $char;
    }

    return $out;
}

sub write_ctrl_agent_config {
    my ( $self, $intent, %opts ) = @_;

    $opts{path} ||= $self->ctrl_agent_config_file();
    $opts{validator} ||= sub { $self->validate_ctrl_agent_config(@_) };
    return $self->_write_json_file( $self->render_ctrl_agent_config($intent), %opts );
}

sub validate_dhcp4_config {
    my ( $self, $path ) = @_;

    return $self->_validate_config_with( 'kea-dhcp4', 'Kea DHCPv4', $path );
}

sub validate_dhcp6_config {
    my ( $self, $path ) = @_;

    return $self->_validate_config_with( 'kea-dhcp6', 'Kea DHCPv6', $path );
}

sub validate_ddns_config {
    my ( $self, $path ) = @_;

    return $self->_validate_config_with( 'kea-dhcp-ddns', 'Kea DHCP-DDNS', $path );
}

sub validate_ctrl_agent_config {
    my ( $self, $path ) = @_;

    return $self->_validate_config_with( 'kea-ctrl-agent', 'Kea Control Agent', $path );
}

sub _validate_config_with {
    my ( $self, $command, $label, $path ) = @_;

    my $kea = _command_path($command);
    return { error => "Unable to validate $label configuration: $command was not found." } unless $kea;

    my $prefix = '';
    if ( $> == 0 ) {
        my $service_account = $self->service_account();
        my $runuser  = _command_path('runuser');
        # Validate as the daemon user when possible so root does not hide
        # packaged Kea runtime-directory or config-readability failures.
        $prefix = _shell_quote($runuser) . ' -u ' . _shell_quote( $service_account->{name} ) . ' -- '
          if $service_account && $runuser;
    }

    my $cmd = $prefix . _shell_quote($kea) . " -t " . _shell_quote($path) . " 2>&1";
    my $output = `$cmd`;
    my $rc = $? >> 8;
    return { error => "$label configuration validation failed: $output" } if $rc != 0;

    return { output => $output };
}

# Which control socket each daemon answers on. The name has to match what
# render_ctrl_agent_config hands the agent, or a reload would be sent into a
# socket nobody is reading.
my %CONTROL_SOCKET_OF = (
    'kea-dhcp4'     => 'kea4-ctrl-socket',
    'kea-dhcp6'     => 'kea6-ctrl-socket',
    'kea-dhcp-ddns' => 'kea-ddns-ctrl-socket',
);

# Ask the running daemon to reload, and find out whether it did.
#
# `systemctl reload` sends SIGHUP and reports success as soon as the signal is
# delivered, whether or not Kea accepted the file. The control socket answers with
# the result of the reload itself.
#
# Returns 0 when the daemon confirmed the new configuration, non-zero on anything
# else, so the caller can fall back to a restart.
sub reload_via_control_socket {
    my ( $self, $service ) = @_;

    my $name = $CONTROL_SOCKET_OF{$service} or return -1;
    my $path = $self->control_socket_path($name);
    return -1 unless -S $path;

    require IO::Socket::UNIX;
    my $sock = IO::Socket::UNIX->new( Type => IO::Socket::UNIX::SOCK_STREAM(), Peer => $path )
      or return -1;

    print $sock JSON->new->encode( { command => 'config-reload' } );
    $sock->shutdown(1);

    my $answer = do { local $/; <$sock> };
    close $sock;
    return -1 unless defined $answer && length $answer;

    my $decoded = eval { JSON->new->decode($answer) };
    return -1 if $@ || ref($decoded) ne 'HASH';

    # Kea answers 0 for success and names the reason otherwise. Passing the
    # reason on is the whole point: "is not present in the system" is a
    # sentence an operator can act on, and a silent SIGHUP is not.
    return 0 if defined $decoded->{result} && $decoded->{result} == 0;
    return $decoded->{text} || -1;
}

sub restart_services {
    my ( $self, %opts ) = @_;

    require xCAT::Utils;

    my @services;
    push @services, 'kea-dhcp-ddns'   if $opts{ddns};
    push @services, 'kea-dhcp4';
    push @services, 'kea-dhcp6'       if $opts{ipv6};
    push @services, 'kea-ctrl-agent'  if $opts{ctrl_agent};

    my @units;
    foreach my $service (@services) {
        my $unit = $self->_kea_service($service);
        push @units, $unit;
        if ( $opts{enable} ) {
            my $enable_ret = xCAT::Utils->enableservice($unit);
            return { error => "Failed to enable $unit." } if $enable_ret != 0;
        }
        my $ret;
        if ( xCAT::Utils->checkservicestatus($unit) == 0 ) {
            # Already running: reload the config instead of a full restart. A
            # restart counts against systemd's start-rate limit
            # (StartLimitBurst=5/10s on EL), which a burst of makedhcp calls trips.
            if ( $CONTROL_SOCKET_OF{$service} ) {
                $ret = $self->reload_via_control_socket($service);
                # No socket, no answer, or a rejection: fall through to the
                # restart below, which re-reads the file from a clean start.
                $ret = 1 if $ret ne '0';
            } else {
                # The Control Agent serves no clients of its own, so a stale
                # configuration there cannot silently strand a network the way
                # a stale kea-dhcp4 can. It keeps the cheaper signal.
                xCAT::Utils->runcmd("systemctl reload $unit", -1);
                $ret = $::RUNCMD_RC;
            }
        }
        if ( !defined($ret) || $ret != 0 ) {
            # Not running (first start) or reload failed: clear any start-limit latch,
            # then do a full restart.
            xCAT::Utils->runcmd("systemctl reset-failed $unit", -1);
            $ret = xCAT::Utils->restartservice($unit);
        }
        return { error => "Failed to restart $unit." } if $ret != 0;
    }

    return { services => \@units };
}

sub check_services {
    my ( $self, %opts ) = @_;

    require xCAT::Utils;

    my @services = ('kea-dhcp4');
    push @services, 'kea-dhcp6' if $opts{ipv6};

    my @units;
    foreach my $service (@services) {
        my $unit = $self->_kea_service($service);
        push @units, $unit;
        my $ret = xCAT::Utils->checkservicestatus($unit);
        return { error => "$unit is not running. Please start the Kea DHCP service." } if $ret != 0;
    }

    return { services => \@units };
}

sub upsert_reservations {
    my ( $self, $config, $reservations, $deleted ) = @_;

    # Remove stale matches before adding the complete requested set.  A DHCPv6
    # client DUID is valid in more than one subnet, so deleting while adding
    # would otherwise remove an earlier reservation from the same batch.
    foreach my $reservation (@$reservations) {
        my $removed = $self->delete_reservations($config, $reservation);
        push @$deleted, @$removed if $deleted;
    }

    foreach my $reservation (@$reservations) {
        my $subnet = _find_subnet_by_id( $config, $reservation->{'subnet-id'} );
        next unless $subnet;
        $subnet->{reservations} ||= [];
        $subnet->{reservations} = [
            grep { !_reservation_matches( $_, $reservation ) } @{ $subnet->{reservations} }
        ];

        my %stored = %$reservation;
        delete $stored{'subnet-id'};
        push @{ $subnet->{reservations} }, \%stored;
    }

    return $config;
}

sub delete_reservations {
    my ( $self, $config, $match ) = @_;

    my @deleted;
    foreach my $subnet ( _subnets_for_config($config) ) {
        my @kept;
        foreach my $reservation ( @{ $subnet->{reservations} || [] } ) {
            if ( _reservation_matches( $reservation, $match ) ) {
                push @deleted, { %$reservation, 'subnet-id' => $subnet->{id} };
            } else {
                push @kept, $reservation;
            }
        }
        $subnet->{reservations} = \@kept;
    }

    return \@deleted;
}

sub query_reservations {
    my ( $self, $config, $match ) = @_;

    my @found;
    foreach my $subnet ( _subnets_for_config($config) ) {
        foreach my $reservation ( @{ $subnet->{reservations} || [] } ) {
            if ( _reservation_matches( $reservation, $match ) ) {
                push @found, { %$reservation, 'subnet-id' => $subnet->{id}, subnet => $subnet->{subnet} };
            }
        }
    }

    return \@found;
}

sub subnet_id_for_ip {
    my ( $self, $config, $ip ) = @_;

    return unless defined($ip) && $ip ne '';
    my $ip_number = xCAT::NetworkUtils::getipaddr( $ip, GetNumber => 1 );
    return unless defined($ip_number);
    my $bits = $ip =~ /:/ ? 128 : 32;

    foreach my $subnet ( _subnets_for_config($config) ) {
        next unless $subnet->{subnet} && $subnet->{subnet} =~ m{^([^/]+)/(\d+)$};
        my ( $network, $prefix ) = ( $1, $2 );
        next if ( $network =~ /:/ ? 128 : 32 ) != $bits;
        my $network_number = xCAT::NetworkUtils::getipaddr( $network, GetNumber => 1 );
        next unless defined($network_number);

        my $mask = Math::BigInt->new( "0b" . ( "1" x $prefix ) . ( "0" x ( $bits - $prefix ) ) );
        return $subnet->{id} if ( $ip_number & $mask ) == ( $network_number & $mask );
    }

    return;
}

sub control_agent_url {
    my ( $self, %opts ) = @_;

    my $host = $opts{host} || $self->{control_agent_host} || '127.0.0.1';
    my $port = $opts{port} || $self->{control_agent_port} || 8000;
    my $authority = xCAT::NetworkUtils->format_host_port($host, $port);
    return unless $authority;
    return "http://$authority/";
}

sub control_agent_command {
    my ( $self, $command, $arguments, %opts ) = @_;

    my $payload = {
        command   => $command,
        arguments => $arguments || {},
    };
    $payload->{service} = $opts{service} if $opts{service};

    if ( $self->{control_agent_handler} ) {
        return $self->{control_agent_handler}->($payload, \%opts);
    }

    eval { require HTTP::Tiny; };
    return { error => "Unable to use Kea Control Agent: HTTP::Tiny is not installed." } if $@;

    my $response = HTTP::Tiny->new( timeout => $opts{timeout} || 10 )->post(
        $opts{url} || $self->control_agent_url(%opts),
        {
            headers => {
                'Content-Type' => 'application/json',
            },
            content => $self->encode_config($payload),
        }
    );

    return { error => "Kea Control Agent request failed: $response->{reason}" } unless $response->{success};

    my $decoded = eval { decode_json( $response->{content} ) };
    return { error => "Unable to parse Kea Control Agent response: $@" } if $@;

    return $self->_normalize_control_agent_response($decoded);
}

sub live_upsert_reservations {
    my ( $self, $reservations, %opts ) = @_;

    my $service = $opts{service} || ['dhcp4'];
    my @delete = (
        @{ $opts{stale_reservations} || [] },
        @$reservations,
    );
    my %seen;
    foreach my $reservation (@delete) {
        my ( $identifier_type, $identifier );
        if ($reservation->{'hw-address'}) {
            ( $identifier_type, $identifier ) = ( 'hw-address', $reservation->{'hw-address'} );
        } elsif ($reservation->{duid}) {
            ( $identifier_type, $identifier ) = ( 'duid', $reservation->{duid} );
        } elsif ($reservation->{'ip-address'}) {
            ( $identifier_type, $identifier ) = ( 'ip-address', $reservation->{'ip-address'} );
        } elsif (ref($reservation->{'ip-addresses'}) eq 'ARRAY' && @{ $reservation->{'ip-addresses'} }) {
            ( $identifier_type, $identifier ) = ( 'ip-address', $reservation->{'ip-addresses'}[0] );
        }
        my $key = join('|',
            map { defined($_) ? lc($_) : '' }
              $reservation->{'subnet-id'}, $identifier_type, $identifier,
        );
        next if $seen{$key}++;
        my $delete = $self->_live_delete_reservation($reservation, service => $service, ignore_not_found => 1);
        return $delete if $delete->{error};
    }

    foreach my $reservation (@$reservations) {
        my ($stored) = @{ _render_entry_option_data( [$reservation] ) };
        my $result = $self->control_agent_command(
            'reservation-add',
            {
                reservation        => $stored,
                'operation-target' => 'memory',
            },
            service => $service,
        );
        return $result if $result->{error};
    }

    return { ok => 1 };
}

sub live_delete_reservations {
    my ( $self, $reservations, %opts ) = @_;

    my $service = $opts{service} || ['dhcp4'];
    foreach my $reservation (@$reservations) {
        my $result = $self->_live_delete_reservation($reservation, service => $service, ignore_not_found => 1);
        return $result if $result->{error};
    }

    return { ok => 1 };
}

sub _live_delete_reservation {
    my ( $self, $reservation, %opts ) = @_;

    return { ok => 1 } unless defined $reservation->{'subnet-id'};

    my %arguments = (
        'subnet-id'        => $reservation->{'subnet-id'},
        'operation-target' => 'memory',
    );
    if ( $reservation->{'hw-address'} ) {
        $arguments{'identifier-type'} = 'hw-address';
        $arguments{identifier} = $reservation->{'hw-address'};
    } elsif ( $reservation->{duid} ) {
        $arguments{'identifier-type'} = 'duid';
        $arguments{identifier} = $reservation->{duid};
    } elsif ( $reservation->{'ip-address'} ) {
        $arguments{'ip-address'} = $reservation->{'ip-address'};
    } elsif ( ref( $reservation->{'ip-addresses'} ) eq 'ARRAY' && @{ $reservation->{'ip-addresses'} } ) {
        $arguments{'ip-address'} = $reservation->{'ip-addresses'}[0];
    } else {
        return { ok => 1 };
    }

    my $result = $self->control_agent_command(
        'reservation-del',
        \%arguments,
        service => $opts{service} || ['dhcp4'],
    );
    return { ok => 1 } if $opts{ignore_not_found} && _control_agent_not_found($result);
    return $result if $result->{error};
    return { ok => 1 };
}

sub _render_subnet4 {
    my ( $self, $subnet ) = @_;

    my %rendered = (
        id     => _integer( $subnet->{id} ),
        subnet => $subnet->{subnet},
    );

    $rendered{interface}        = $subnet->{interface} if defined $subnet->{interface};
    $rendered{'next-server'}    = _first_defined( $subnet->{'next-server'},    $subnet->{next_server} );
    $rendered{'boot-file-name'} = _first_defined( $subnet->{'boot-file-name'}, $subnet->{boot_file_name} );
    $rendered{'option-data'} = _render_option_data(
        _first_defined( $subnet->{'option-data'}, $subnet->{option_data} )
    );
    my $additional_classes = _first_defined(
        $subnet->{additional_client_classes},
        $subnet->{'evaluate-additional-classes'},
        $subnet->{evaluate_additional_classes},
        $subnet->{'require-client-classes'},
        $subnet->{require_client_classes},
    );
    $rendered{ $self->_additional_class_list_field() } = $additional_classes if defined $additional_classes;
    $rendered{reservations} = _render_entry_option_data( $subnet->{reservations} )
      if $subnet->{reservations};
    delete $rendered{'next-server'}    unless defined $rendered{'next-server'};
    delete $rendered{'boot-file-name'} unless defined $rendered{'boot-file-name'};
    delete $rendered{'option-data'}    unless defined $rendered{'option-data'};

    if ( $subnet->{pools} ) {
        $rendered{pools} = _render_entry_option_data( $subnet->{pools} );
    } elsif ( $subnet->{dynamicrange} ) {
        $rendered{pools} = [ xCAT::DHCP::Range->kea_pools( $subnet->{dynamicrange} ) ];
    } else {
        $rendered{pools} = [];
    }

    return \%rendered;
}

sub _render_client_class {
    my ( $self, $client_class ) = @_;

    my %rendered = %$client_class;
    my $additional_only = _first_defined(
        $client_class->{additional_only},
        $client_class->{'only-in-additional-list'},
        $client_class->{only_in_additional_list},
        $client_class->{'only-if-required'},
        $client_class->{only_if_required},
    );

    delete @rendered{qw/additional_only only_in_additional_list only_if_required/};
    delete $rendered{'only-in-additional-list'};
    delete $rendered{'only-if-required'};
    $rendered{ $self->_additional_class_flag_field() } = _json_bool($additional_only)
      if defined $additional_only;
    $rendered{'option-data'} = _render_option_data( $rendered{'option-data'} )
      if $rendered{'option-data'};

    return \%rendered;
}

# Kea reads the option flags as booleans, so the callers can set them the plain
# Perl way and still produce a configuration the server parses.
sub _render_option_data {
    my ($option_data) = @_;

    return $option_data unless ref($option_data) eq 'ARRAY';

    my @rendered;
    foreach my $option (@$option_data) {
        if ( ref($option) ne 'HASH' ) {
            push @rendered, $option;
            next;
        }
        my %copy = %$option;
        foreach my $flag (qw/always-send csv-format never-send/) {
            $copy{$flag} = _json_bool( $copy{$flag} ) if defined $copy{$flag};
        }
        push @rendered, \%copy;
    }

    return \@rendered;
}

sub _render_entry_option_data {
    my ($entries) = @_;

    return $entries unless ref($entries) eq 'ARRAY';

    my @rendered;
    foreach my $entry (@$entries) {
        if ( ref($entry) ne 'HASH' ) {
            push @rendered, $entry;
            next;
        }
        my %copy = %$entry;
        $copy{'option-data'} = _render_option_data( $copy{'option-data'} )
          if $copy{'option-data'};
        push @rendered, \%copy;
    }

    return \@rendered;
}

sub _render_subnet6 {
    my ( $self, $subnet ) = @_;

    my %rendered = (
        id     => _integer( $subnet->{id} ),
        subnet => $subnet->{subnet},
    );

    $rendered{interface}     = $subnet->{interface} if defined $subnet->{interface};
    $rendered{'option-data'} = _render_option_data(
        _first_defined( $subnet->{'option-data'}, $subnet->{option_data} )
    );
    $rendered{reservations} = _render_entry_option_data( $subnet->{reservations} )
      if $subnet->{reservations};
    delete $rendered{'option-data'} unless defined $rendered{'option-data'};

    if ( $subnet->{pools} ) {
        $rendered{pools} = _render_entry_option_data( $subnet->{pools} );
    } elsif ( $subnet->{dynamicrange} ) {
        $rendered{pools} = [ xCAT::DHCP::Range->kea_pools( $subnet->{dynamicrange} ) ];
    } else {
        $rendered{pools} = [];
    }

    return \%rendered;
}

sub _find_subnet_by_id {
    my ( $config, $subnet_id ) = @_;

    return unless defined($subnet_id);
    foreach my $subnet ( _subnets_for_config($config) ) {
        return $subnet if defined( $subnet->{id} ) && $subnet->{id} == $subnet_id;
    }

    return;
}

sub _subnets_for_config {
    my ($config) = @_;

    return @{ $config->{Dhcp4}{subnet4} || [] } if $config->{Dhcp4};
    return @{ $config->{Dhcp6}{subnet6} || [] } if $config->{Dhcp6};
    return;
}

sub _reservation_matches {
    my ( $reservation, $match ) = @_;

    foreach my $field ( 'hostname', 'hw-address', 'duid', 'ip-address' ) {
        next unless defined $match->{$field} && $match->{$field} ne '';
        next unless defined $reservation->{$field};
        my ( $have, $want ) = ( lc( $reservation->{$field} ), lc( $match->{$field} ) );

        # A hostname written by another tool may be fully qualified, with the
        # trailing dot that says so. A caller looking a node up by name has no
        # reason to know that, so the dot is not part of the comparison.
        if ( $field eq 'hostname' ) {
            s/\.$// foreach ( $have, $want );
        }
        return 1 if $have eq $want;
    }
    if ( defined $match->{'ip-address'} && ref( $reservation->{'ip-addresses'} ) eq 'ARRAY' ) {
        foreach my $ip ( @{ $reservation->{'ip-addresses'} } ) {
            return 1 if lc($ip) eq lc( $match->{'ip-address'} );
        }
    }

    return 0;
}

sub _normalize_control_agent_response {
    my ( $self, $decoded ) = @_;

    my $item = ref($decoded) eq 'ARRAY' ? $decoded->[0] : $decoded;
    return { error => 'Kea Control Agent response was empty.' } unless ref($item) eq 'HASH';

    return {
        ok       => defined( $item->{result} ) && $item->{result} == 0 ? 1 : 0,
        result   => $item->{result},
        text     => $item->{text},
        response => $decoded,
        error    => defined( $item->{result} ) && $item->{result} == 0 ? undef : ( $item->{text} || 'Kea Control Agent command failed.' ),
    };
}

sub _control_agent_not_found {
    my ($result) = @_;

    return 0 unless $result && $result->{error};
    return 1 if defined( $result->{result} ) && $result->{result} == 3;
    return 1 if defined( $result->{text} ) && $result->{text} =~ /not\s+(?:deleted|found)/i;
    return 0;
}

sub _additional_class_flag_field {
    my ($self) = @_;

    return $self->_use_modern_additional_class_syntax() ? 'only-in-additional-list' : 'only-if-required';
}

sub _additional_class_list_field {
    my ($self) = @_;

    return $self->_use_modern_additional_class_syntax() ? 'evaluate-additional-classes' : 'require-client-classes';
}

sub _use_modern_additional_class_syntax {
    my ($self) = @_;

    return 1 if $self->{additional_class_syntax} && $self->{additional_class_syntax} eq 'modern';
    return 0 if $self->{additional_class_syntax} && $self->{additional_class_syntax} eq 'legacy';

    my $version = $self->kea_version();
    return 0 unless defined($version) && $version =~ /\A\d+(?:\.\d+)*(?:-[A-Za-z0-9]+)?\z/;

    require xCAT::Utils;
    return xCAT::Utils->version_cmp( $version, '2.7.4' ) >= 0 ? 1 : 0;
}

sub kea_version {
    my ($self) = @_;

    return $self->{kea_version} if defined $self->{kea_version};
    return $self->{_detected_kea_version} if defined $self->{_detected_kea_version};

    my $output = $self->_kea_command_output('-V') || '';

    if ( $output =~ /(\d+(?:\.\d+){1,2})/ ) {
        $self->{_detected_kea_version} = $1;
    }

    return $self->{_detected_kea_version};
}

sub _kea_build_report {
    my ($self) = @_;

    return $self->{kea_build_report} if defined $self->{kea_build_report};
    return $self->{_detected_kea_build_report} if defined $self->{_detected_kea_build_report};

    my $output = $self->_kea_command_output('-W') || '';

    $self->{_detected_kea_build_report} = $output;
    return $output;
}

sub _kea_command_output {
    my ( $self, @args ) = @_;

    my $command = $self->{kea_dhcp4_command} || _command_path('kea-dhcp4');
    return unless $command;

    my $output = '';
    if ( open( my $command_fh, '-|', $command, @args ) ) {
        local $/;
        $output = <$command_fh> || '';
        close($command_fh);
    }

    return $output;
}

sub _first_defined {
    my @values = @_;
    foreach my $value (@values) {
        return $value if defined $value;
    }

    return;
}

sub _integer {
    my ($value) = @_;

    return $value unless defined($value) && $value =~ /^\d+$/;
    return 0 + $value;
}

sub _json_bool {
    my ($value) = @_;

    return $value if ref($value) eq 'JSON::PP::Boolean' || ref($value) eq 'JSON::Boolean';
    return $value ? JSON::true : JSON::false;
}

sub _set_config_permissions {
    my ($path) = @_;

    if ($> != 0) {
        chmod 0644, $path or return { error => "Unable to set $path permissions to 0644: $!" };
        return { ok => 1 };
    }

    my ( $group, $gid ) = _kea_group();
    if ( defined($gid) ) {
        chown 0, $gid, $path or return { error => "Unable to set $path ownership to root:$group: $!" };
        chmod 0640, $path or return { error => "Unable to set $path permissions to 0640: $!" };
    } else {
        chmod 0644, $path or return { error => "Unable to set $path permissions to 0644: $!" };
    }

    return { ok => 1 };
}

sub _kea_group {
    foreach my $group (@KEA_ACCOUNT_CANDIDATES) {
        my @entry = getgrnam($group);
        return ( $entry[0], $entry[2] ) if @entry;
    }

    return;
}

sub _kea_service {
    my ( $self, $service ) = @_;

    return $service
      unless $service =~ /\Akea-(?:dhcp4|dhcp6|dhcp-ddns|ctrl-agent)\z/;

    require xCAT::Utils;

    # Preserve the backend's established candidate subset while taking the
    # candidate order and filesystem resolution from the shared service map.
    my $candidate_limit = $service eq 'kea-ctrl-agent' ? 1 : 2;
    return xCAT::Utils->servicemap(
        $service,
        {
            candidate_limit => $candidate_limit,
            searches        => [
                {
                    paths  => $self->{service_unit_dirs} || [
                        '/etc/systemd/system',
                        '/run/systemd/system',
                        '/usr/lib/systemd/system',
                        '/lib/systemd/system',
                    ],
                    suffix => '.service',
                },
                {
                    paths      => $self->{service_init_dirs} || ['/etc/init.d'],
                    executable => 1,
                },
            ],
        },
      ) || $service;
}

sub _kea_socket_dir {
    my ($self) = @_;

    return $self->{kea_socket_dir} if defined $self->{kea_socket_dir};

    if ( defined $self->{kea_socket_dirs} ) {
        foreach my $dir ( @{ $self->{kea_socket_dirs} || [] } ) {
            return $dir if -d $dir;
        }
        return '/var/run/kea';
    }

    my $build_report = $self->_kea_build_report();
    if ($build_report) {
        my $prefix = _kea_build_option( $build_report, 'prefix' );
        if ( !defined($prefix) && $build_report =~ /^\s*Prefix:\s*(\/\S+)/m ) {
            $prefix = $1;
        }
        $prefix = _expand_kea_build_path( $prefix, {} );

        # Kea's Meson build unconditionally overrides the installed runtime
        # directory for the /usr/local prefix, even when state directories
        # are supplied as build options.
        if ( defined($prefix) && $prefix eq '/usr/local' && $build_report =~ /^\s*Meson Version:/m ) {
            return '/usr/local/var/run/kea';
        }

        my $local_state = _kea_build_option( $build_report, 'localstatedir' );
        $local_state = _expand_kea_build_path( $local_state, { prefix => $prefix }, $prefix );
        if ( !defined($local_state) && defined($prefix) ) {
            if ( $build_report =~ /^\s*Meson Version:/m ) {
                $local_state = '/var' if $prefix eq '/usr';
            }
            # Kea reverts Meson's /usr/local => /var/local default.
            $local_state = _expand_kea_build_path( 'var', {}, $prefix ) unless defined($local_state);
        }

        my $run_state = _kea_build_option( $build_report, 'runstatedir' );
        $run_state = _expand_kea_build_path(
            $run_state,
            {
                prefix         => $prefix,
                localstatedir  => $local_state,
            },
            $prefix,
        );
        $run_state = "$local_state/run" if !defined($run_state) && defined($local_state);
        return $run_state eq '/' ? '/kea' : "$run_state/kea" if defined($run_state);
    }

    # Kea validates Control Agent sockets against its packaged runtime
    # directory, and newer packages reject a symlink-equivalent spelling.
    # Filesystem probing is only a fallback for builds without a usable report.
    foreach my $dir ( '/run/kea', '/var/run/kea' ) {
        return $dir if -d $dir;
    }

    return '/var/run/kea';
}

sub _kea_build_option {
    my ( $build_report, $option ) = @_;

    return unless defined($build_report);
    my $options = $build_report;
    if ( $build_report =~ /^\s*(?:Configure arguments|Build Options):[ \t]*(.*?)(?=\n[ \t]*\n|^\s*C\+\+ Compiler:|\z)/ms ) {
        $options = $1;
    }

    my @tokens = eval { shellwords($options) };
    return if $@;

    my $value;
    for ( my $index = 0; $index < @tokens; $index++ ) {
        my $token = $tokens[$index];
        if ( $token =~ /^(?:--|-D)\Q$option\E=(.+)$/ ) {
            $value = $1;
        } elsif ( $token eq "--$option" && $index + 1 < @tokens ) {
            $value = $tokens[ ++$index ];
        }
    }

    return $value;
}

sub _expand_kea_build_path {
    my ( $path, $variables, $relative_base ) = @_;

    return unless defined($path);
    foreach my $variable (qw/prefix localstatedir/) {
        next unless defined( $variables->{$variable} );
        $path =~ s/\$\{$variable\}/$variables->{$variable}/g;
    }
    if ( $path !~ m{^/} && defined($relative_base) ) {
        $path = $relative_base eq '/' ? "/$path" : "$relative_base/$path";
    }
    $path =~ s{/$}{} if length($path) > 1;
    return $path if $path =~ m{^/};

    return;
}

sub _command_path {
    my ($command) = @_;
    return xCAT::CommandUtils::find_executable($command);
}

sub _shell_quote {
    my ($value) = @_;

    $value =~ s/'/'\\''/g;
    return "'$value'";
}

1;
